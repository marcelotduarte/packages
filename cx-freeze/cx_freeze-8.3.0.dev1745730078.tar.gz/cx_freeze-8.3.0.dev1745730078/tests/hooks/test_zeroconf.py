"""Tests for cx_Freeze.hooks._zeroconf_."""

from __future__ import annotations

import pytest

zip_packages = pytest.mark.parametrize(
    "zip_packages", [False, True], ids=["", "zip_packages"]
)
SOURCE_TEST = """
test_zeroconf.py
    import zeroconf

    # Add a simple function to keep the program running for a moment
    def main():
        print("Zeroconf imported successfully!")
        print(f"Zeroconf version: {zeroconf.__version__}")

    if __name__ == "__main__":
        main()
pyproject.toml
    [project]
    name = "test_zeroconf"
    version = "0.1.2.3"

    [tool.cxfreeze]
    executables = ["test_zeroconf.py"]

    [tool.cxfreeze.build_exe]
    excludes = ["tkinter", "unittest"]
    packages = ["zeroconf._services"]
    silent = true
"""


@zip_packages
def test_zeroconf(tmp_package, zip_packages: bool) -> None:
    """Test if zeroconf hook is working correctly."""
    tmp_package.create(SOURCE_TEST)
    tmp_package.install("zeroconf")
    if zip_packages:
        pyproject = tmp_package.path / "pyproject.toml"
        buf = pyproject.read_bytes().decode().splitlines()
        buf += ['zip_include_packages = "*"', 'zip_exclude_packages = ""']
        pyproject.write_bytes("\n".join(buf).encode("utf_8"))
    output = tmp_package.run()

    executable = tmp_package.executable("test_zeroconf")
    assert executable.is_file()
    output = tmp_package.run(executable, timeout=10)
    lines = output.splitlines()
    assert lines[0].startswith("Zeroconf imported successfully!")
    assert lines[1].startswith("Zeroconf version:")
