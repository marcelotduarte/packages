cxfreeze script
===============

Freeze a Python script and all of its referenced modules to a standalone \
executable which can then be distributed without requiring a Python \
installation.

Assuming you have a script called ``hello.py`` which you want to turn into an
executable, this can be accomplished by this command:

  .. code-block:: console

    cxfreeze --script hello.py --target-dir dist

Further customization can be done using the following options:

.. program:: cxfreeze

.. option:: --script=NAME

    the name of the file containing the script which is to be frozen

.. option:: --init-script=NAME

    script which will be executed upon startup (before script);
    this script is used to set up the environment for the executable;
    pre-defined values: "console", "streamlit";
    an user-defined initscripts is accepted if it is given with
    an absolute path name [default: console]

.. option:: --base=NAME, --base-name=NAME

    the name of the base executable;
    pre-defined values: "console", "gui", "gui_dgpu" and "service";
    an user-defined base is accepted if it is given with
    an absolute path name [default: console]

.. option:: --target-name=NAME

    the name of the target executable; it is recommended NOT to
    use an extension (automatically added on Windows); --target-name with
    version is supported; if specified a path, raise an error
    [default: the name of script]

.. option:: --target-dir=DIR

    directory for built executables and dependent files

.. option:: --icon=ICON

    name of icon which should be included in the executable itself
    on Windows (ignored by Python app from Microsoft Store) or placed
    in the target directory for other platforms; it is recommended
    NOT to use an extension (automatically added ".ico" on Windows,
    ".icns" on macOS and ".png" or ".svg" on Linux and others)

.. option:: --manifest=NAME

    the name of manifest which should be included in the executable itself
    (Windows only - ignored by Python app from Microsoft Store)

.. option:: --uac-admin

    creates a manifest for an application that will request elevation
    (Windows only - ignored by Python app from Microsoft Store)

.. option:: --uac-uiaccess

    changes the application manifest to bypass user interface control
    (Windows only - ignored by Python app from Microsoft Store)

.. option:: --shortcut-name=NAME

    the name to give a shortcut for the executable when included in
    an MSI package (Windows only)

.. option:: --shortcut-dir=DIR

    the directory in which to place the shortcut when being
    installed by an MSI package; see the MSI Shortcut table documentation
    for more information on what values can be placed here (Windows only)

.. option:: --copyright

    the copyright value to include in the version resource
    associated with executable (Windows only)

.. option:: --trademarks

    the trademarks value to include in the version resource
    associated with the executable (Windows only)

.. option:: --debug

    print debug information

.. option:: --verbose

    run verbosely

.. option:: --version

   show program's version number and exit

.. option:: -h, --help

   show this help message and exit

.. versionadded:: 6.10
    :option:`--manifest` and :option:`--uac-admin` options.

.. versionadded:: 7.0
    :option:`--uac-uiaccess` option.

.. versionchanged:: 7.0
    :option:`--base` option has new pre-defined values: "gui" and "service".
    "console" remains the default value.

.. versionadded:: 8.0
    :option:`--debug` and :option:`--verbose` options.

.. versionchanged:: 8.0
    :option:`--base` option does not accept the old values
    "Win32GUI" and "Win32Service" in Python 3.13+.

.. versionchanged:: 8.6
    :option:`--base` option has a new pre-defined value: "gui_dgpu"
    :option:`--init-script` option has a new pre-defined value: "streamlit"
