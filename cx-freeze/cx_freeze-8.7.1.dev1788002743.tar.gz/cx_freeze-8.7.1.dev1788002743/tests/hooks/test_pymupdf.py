"""Tests for hooks of pymupdf."""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

import pytest

from cx_Freeze._compat import (
    ABI_THREAD,
    IS_ARM_64,
    IS_CONDA,
    IS_LINUX,
    IS_MACOS,
    IS_MINGW,
    IS_WINDOWS,
    IS_X86_64,
)

if TYPE_CHECKING:
    from tests.conftest import TempPackage

TIMEOUT_SLOW = 60 if IS_CONDA else 30

zip_packages = pytest.mark.parametrize(
    "zip_packages", [False, True], ids=["", "zip_packages"]
)

SOURCE_TEST_PYMUPDF = """
test_pymupdf.py
    import pymupdf

    print("Hello from cx_Freeze")
    print("pymupdf version", pymupdf.__version__)
pyproject.toml
    [project]
    name = "test_pymupdf"
    version = "0.1.2.3"
    dependencies = ["pymupdf"]

    [tool.cxfreeze]
    executables = ["test_pymupdf.py"]

    [tool.cxfreeze.build_exe]
    include-msvcr = true
    excludes = ["tkinter"]
    silent = true
"""


@pytest.mark.xfail(
    sys.version_info[:2] >= (3, 15) and ABI_THREAD == "t",
    raises=ModuleNotFoundError,
    reason="pymupdf does not support Python 3.15t yet",
    strict=not bool(int(os.getenv("PYTEST_LAX_XFAIL", "0"))),
)
@pytest.mark.xfail(
    sys.version_info[:2] == (3, 14)
    and ABI_THREAD == "t"
    and not (IS_LINUX and IS_X86_64),
    raises=ModuleNotFoundError,
    reason="pymupdf support Python 3.14t only in Linux x86_64",
    strict=not bool(int(os.getenv("PYTEST_LAX_XFAIL", "0"))),
)
@pytest.mark.skipif(
    IS_CONDA and (IS_LINUX or IS_WINDOWS or (IS_ARM_64 and IS_MACOS)),
    reason="pymupdf is broken in conda-forge (except on OSX64)",
)
@pytest.mark.skipif(IS_MINGW, reason="pymupdf is broken in mingw")
@pytest.mark.venv
@zip_packages
def test_pymupdf(tmp_package: TempPackage, zip_packages: bool) -> None:
    """Test if pymupdf hook is working correctly."""
    tmp_package.create(SOURCE_TEST_PYMUPDF)
    if zip_packages:
        pyproject = tmp_package.path / "pyproject.toml"
        buf = pyproject.read_bytes().decode().splitlines()
        buf += ['zip_include_packages = "*"', 'zip_exclude_packages = ""']
        pyproject.write_bytes("\n".join(buf).encode("utf_8"))
    tmp_package.freeze()
    executable = tmp_package.executable("test_pymupdf")
    assert executable.is_file()
    result = tmp_package.run(executable, timeout=TIMEOUT_SLOW)
    result.stdout.fnmatch_lines(["Hello from cx_Freeze", "pymupdf version *"])
