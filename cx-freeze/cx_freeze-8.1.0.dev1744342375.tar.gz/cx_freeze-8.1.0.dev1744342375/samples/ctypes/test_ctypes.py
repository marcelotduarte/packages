from __future__ import annotations

import ctypes

print("Hello", ctypes.__name__)
