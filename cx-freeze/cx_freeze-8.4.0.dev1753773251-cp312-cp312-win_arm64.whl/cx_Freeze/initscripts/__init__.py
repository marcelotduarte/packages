"""Python scripts which set up the interpreter to run from frozen code, then
load the code from the zip file and set it running.
"""
