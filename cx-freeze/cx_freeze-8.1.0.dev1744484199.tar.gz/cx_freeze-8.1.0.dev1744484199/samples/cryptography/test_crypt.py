from __future__ import annotations

from cryptography.fernet import Fernet

print("Hello cryptography", Fernet)
