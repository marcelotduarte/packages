"""Module Finder - discovers what modules are required by the code."""

from __future__ import annotations

import _imp
import inspect
import json
import linecache
import logging
import os
import sys
import traceback
from contextlib import suppress
from functools import cached_property
from importlib import import_module
from importlib.machinery import (
    BYTECODE_SUFFIXES,
    EXTENSION_SUFFIXES,
    SOURCE_SUFFIXES,
    BuiltinImporter,
    ExtensionFileLoader,
    FrozenImporter,
    ModuleSpec,
    PathFinder,
    SourceFileLoader,
    SourcelessFileLoader,
)
from importlib.metadata import (
    Distribution,
    distributions,
    packages_distributions,
)
from pathlib import Path
from pkgutil import resolve_name
from sysconfig import get_config_var
from tempfile import TemporaryDirectory
from types import CodeType, FrameType, TracebackType
from typing import TYPE_CHECKING

from cx_Freeze._bytecode import (
    code_object_replace,
    code_object_replace_package,
    scan_code,
)
from cx_Freeze._compat import IS_WINDOWS, SOABI
from cx_Freeze.common import process_path_specs, resource_path
from cx_Freeze.hooks.unused_modules import (
    DEFAULT_EXCLUDES,
    DEFAULT_IGNORE_NAMES,
)
from cx_Freeze.module import ConstantsModule, Module

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from importlib.abc import Loader

    from cx_Freeze._typing import (
        DeferredList,
        IncludesList,
        InternalIncludesList,
        StrPath,
    )

ALL_SUFFIXES = SOURCE_SUFFIXES + BYTECODE_SUFFIXES + EXTENSION_SUFFIXES


__all__ = ["ModuleFinder"]

logger = logging.getLogger(__name__)


class ModuleFinder:
    """ModuleFinder base class."""

    def __init__(
        self,
        constants_module: ConstantsModule,
        *,
        excludes: list[str] | None = None,
        include_files: IncludesList | None = None,
        optimize: int = 0,
        path: list[StrPath] | None = None,
        replace_paths: list[tuple[str, str]] | None = None,
        zip_exclude_packages: Sequence[str] | None = None,
        zip_include_packages: Sequence[str] | None = None,
        zip_include_all_packages: bool = False,
        zip_includes: IncludesList | None = None,
    ) -> None:
        self.included_files: InternalIncludesList = process_path_specs(
            include_files
        )
        self.optimize = optimize
        self.path: list[str] = [os.path.normpath(p) for p in path or sys.path]
        self.replace_paths: list[tuple[str, str]] = replace_paths or []
        self.zip_include_all_packages: bool = zip_include_all_packages
        self.zip_exclude_packages: set[str] = set(zip_exclude_packages or [])
        self.zip_include_packages: set[str] = set(zip_include_packages or [])
        self.constants_module: ConstantsModule = constants_module
        self.zip_includes: InternalIncludesList = process_path_specs(
            zip_includes
        )
        self.namespaces: list[Module] = []
        self.aliases: dict[str, str] = {}
        self.excluded_dependent_files: set[Path] = set()
        self._bad_modules: dict[str, set[str]] = {}
        # add the unused modules in the current platform
        self._modules: dict[str, Module | None] = dict.fromkeys(
            set(excludes or []) | DEFAULT_EXCLUDES
        )
        self._tmp_dir = TemporaryDirectory(prefix="cxfreeze-")
        self.cache_path = Path(self._tmp_dir.name)
        self.lib_files: dict[Path, str] = {}

    def cleanup(self) -> None:
        self._tmp_dir.cleanup()

    def _add_module(
        self,
        name: str,
        path: Sequence[StrPath] | None = None,
        filename: StrPath | None = None,
        parent: Module | None = None,
    ) -> Module:
        """Add a module to the list of modules.

        If one is already found, then return it instead;
        this is done so that packages can be handled properly.
        """
        module = self._modules.get(name)
        if module is None:
            module = Module(name, path, filename, parent)
            self._modules[name] = module
            if name in self._bad_modules:
                logger.debug(
                    "Removing module [%s] from list of bad modules", name
                )
                del self._bad_modules[name]
            if (
                self.zip_include_all_packages
                and module.name not in self.zip_exclude_packages
            ) or module.name in self.zip_include_packages:
                module.in_file_system = 0
        if module.path is None and path is not None:
            module.path = list(map(Path, path))
        if module.file is None and filename is not None:
            module.file = filename
        if module.finder is None:
            module.finder = self
            root_name = name.split(".", maxsplit=1)[0]
            if (
                name not in self.builtin_modules
                and root_name not in sys.stdlib_module_names
            ):
                module.update_distribution()
        return module

    def _determine_parent(self, caller: Module | None) -> Module | None:
        """Determine the parent to use when searching packages."""
        if caller is not None:
            if caller.path is not None:
                return caller
            return self._get_parent_by_name(caller.name)
        return None

    def _ensure_from_list(
        self,
        caller: Module,
        package_module: Module,
        from_list: list[str],
        deferred_imports: DeferredList,
    ) -> None:
        """Ensure that the from list is satisfied.

        This is only necessary for package modules. If the package module
        has not been completely imported yet, defer the import until it has
        been completely imported in order to avoid spurious errors about
        missing modules.
        """
        if package_module.in_import and caller is not package_module:
            deferred_imports.append((caller, package_module, from_list))
        else:
            for name in from_list:
                if name in package_module.global_names:
                    continue
                sub_module_name = f"{package_module.name}.{name}"
                self._import_module(sub_module_name, deferred_imports, caller)

    def _get_parent_by_name(self, name: str) -> Module | None:
        """Return the parent module given the name of a module."""
        pos = name.rfind(".")
        if pos > 0:
            parent_name = name[:pos]
            return self._modules[parent_name]
        return None

    def _import_all_sub_modules(
        self,
        module: Module,
        deferred_imports: DeferredList,
        recursive: bool = True,
    ) -> None:
        """Import all sub modules to the given package."""
        if module.path is None:
            return
        for path in module.path:
            for fullname in path.iterdir():
                if fullname.is_dir():
                    if not fullname.joinpath("__init__.py").exists():
                        continue
                    name = fullname.name
                else:
                    # We need to run through these in order to correctly
                    # pick up PEP 3149 library names
                    # (e.g. .cpython-311-x86_64-linux-gnu.so).
                    for suffix in ALL_SUFFIXES:
                        if fullname.name.endswith(suffix):
                            name = fullname.name.removesuffix(suffix)

                            # Skip modules whose names appear to contain '.',
                            # as we may be using the wrong suffix, and even if
                            # we're not, such module names will break the
                            # import code.
                            if "." not in name:
                                break

                    else:
                        continue
                    if name == "__init__":
                        continue

                sub_module_name = f"{module.name}.{name}"
                sub_module = self._internal_import_module(
                    sub_module_name, deferred_imports
                )
                if sub_module is None:
                    if sub_module_name not in self._modules:
                        msg = f"No module named {sub_module_name!r}"
                        raise ImportError(msg, name=sub_module_name)
                else:
                    module.global_names.add(name)
                    if sub_module.path and recursive:
                        self._import_all_sub_modules(
                            sub_module, deferred_imports, recursive
                        )

    def _import_deferred_imports(
        self, deferred_imports: DeferredList, skip_in_import: bool = False
    ) -> None:
        """Import any sub modules that were deferred, if applicable."""
        while deferred_imports:
            new_deferred_imports: DeferredList = []
            for caller, package_module, sub_module_names in deferred_imports:
                if package_module.in_import and skip_in_import:
                    continue
                self._ensure_from_list(
                    caller,
                    package_module,
                    sub_module_names,
                    new_deferred_imports,
                )
            deferred_imports = new_deferred_imports
            skip_in_import = True

    def _import_module(
        self,
        name: str,
        deferred_imports: DeferredList,
        caller: Module | None = None,
        relative_import_index: int = 0,
    ) -> Module | None:
        """Attempt to find the named module.

        Return the module name or None if no module could be found.
        """
        # absolute import: search only by the given name.
        if relative_import_index == 0:
            module = self._internal_import_module(name, deferred_imports)

        # old style relative import (regular 'import foo' in Python 2)
        # the name given is tried in the current package, and if no match
        # is found, self.path is searched for a top-level module/package
        elif relative_import_index < 0:
            parent = self._determine_parent(caller)
            if parent is not None:
                fullname = f"{parent.name}.{name}"
                module = self._internal_import_module(
                    fullname, deferred_imports
                )
                if module is not None:
                    parent.global_names.add(name)
                    return module

            module = self._internal_import_module(name, deferred_imports)

        # new style relative import (available in Python 2.5 and up)
        # the index indicates how many levels to traverse and only that level
        # is searched for the named module
        elif relative_import_index > 0:
            parent = caller
            if parent and parent.path is not None:
                relative_import_index -= 1
            while parent is not None and relative_import_index > 0:
                parent = self._get_parent_by_name(parent.name)
                relative_import_index -= 1
            if parent is None:
                module = None
            elif not name:
                module = parent
            else:
                name = f"{parent.name}.{name}"
                module = self._internal_import_module(name, deferred_imports)

        else:
            module = None

        # if module not found, track that fact
        if module is None:
            if caller is None:
                msg = f"No module named {name!r}"
                raise ImportError(msg, name=name)
            self._missing_hook(caller, name)

        return module

    def _internal_import_module(
        self, name: str, deferred_imports: DeferredList
    ) -> Module | None:
        """Add the module to the internal import list.

        Assumes that the name given is an absolute name.
        None is returned if the module cannot be found.
        """
        with suppress(KeyError):
            # Check in module cache before trying to import it again.
            return self._modules[name]

        pos = name.rfind(".")
        if pos < 0:  # Top-level module
            path = self.path
            parent_module = None
        else:  # Dotted module name - look up the parent module
            parent_name = name[:pos]
            parent_module = self._internal_import_module(
                parent_name, deferred_imports
            )
            if parent_module is None:
                return None
            parent_path = parent_module.path
            if parent_path is None:
                path = self.path
            else:
                path = [os.path.normpath(p) for p in parent_path]
                if parent_module in self.namespaces:
                    for pathname in self.path:
                        pathtoadd = os.path.join(pathname, parent_name)
                        if os.path.isdir(pathtoadd) and pathtoadd not in path:
                            path.append(pathtoadd)

        # Search for an alias of a module or package.
        pos = len(name)
        while pos >= 0:
            actual_name = self.aliases.get(name[:pos])
            if actual_name is not None:
                break
            pos = name.rfind(".", 0, pos)
        if actual_name:
            actual_name += name[pos:]
            module = self._internal_import_module(
                actual_name, deferred_imports
            )
            self._modules[name] = module
            return module

        module = self._load_module(name, path, deferred_imports, parent_module)
        if module is None:
            logger.debug("Module [%s] cannot be imported", name)
            self._modules[name] = None
            return None
        return module

    def _find_editable_spec(
        self, name: str, path: Sequence[str] | None
    ) -> ModuleSpec | None:
        """Find the spec for a module installed as an editable package."""
        # the distribution name may vary from the module name (eg may
        # include '-'). packages_distributions returns the mapping
        dist = self.import_distributions.get(name)
        if not dist or not dist.files:
            return None
        for f in dist.files:
            if f.match("__editable__*_finder.py"):
                try:
                    mod = import_module(f.stem)
                    edt = mod._EditableFinder  # noqa: SLF001
                    spec = edt.find_spec(name, path)
                    if spec:
                        return spec
                except (ImportError, AttributeError) as exc:
                    msg = "Find editable spec failed for [%s]: %s"
                    logger.warning(msg, name, exc)
                    break
        return None

    def _load_module(
        self,
        name: str,
        path: Sequence[str],
        deferred_imports: DeferredList,
        parent: Module | None = None,
    ) -> Module | None:
        """Load the module, searching the module spec."""
        spec: ModuleSpec | None = None
        module: Module | None = None

        # It's recommended to clear the caches first.
        if parent is None:
            PathFinder.invalidate_caches()

        # Find modules to load
        try:
            spec = PathFinder.find_spec(name, path)
        except (KeyError, ModuleNotFoundError):
            if parent:
                # some packages use a directory with vendor modules without
                # an __init__.py, thus, are called nested namespace packages
                path = [
                    os.path.join(p, name.rpartition(".")[-1]) for p in path
                ]
                module = self._add_module(name, path=path, parent=parent)
                logger.debug("Adding module [%s] [NESTED NAMESPACE]", name)
                self.namespaces.append(module)
                module.in_import = False
                return module

        if not spec:
            spec = BuiltinImporter.find_spec(name)

        if not spec:
            spec = FrozenImporter.find_spec(name)

        if not spec:
            spec = self._find_editable_spec(name, path)

        if spec:
            # Load module, package or namespace package
            module = self._add_module(
                name,
                path=spec.submodule_search_locations,
                filename=spec.origin,
                parent=parent,
            )
            if spec.origin is None:
                logger.debug("Adding module [%s] [NAMESPACE]", name)
                self.namespaces.append(module)
                module.in_import = False
                return module

            module.loader = spec.loader
            if spec.origin in ("built-in", "frozen"):
                logger.debug(
                    "Adding module [%s] [%s]", name, spec.origin.upper()
                )
                self._load_module_code_builtins(module, deferred_imports)
            else:
                if spec.submodule_search_locations:
                    logger.debug("Adding module [%s] [PACKAGE]", name)
                else:
                    logger.debug("Adding module [%s] [MODULE]", name)
                if self._load_module_code(module, deferred_imports):
                    self._load_module_code_libraries(module)
        return module

    def _load_module_code(
        self, module: Module, deferred_imports: DeferredList
    ) -> bool:
        loader: Loader | None = module.loader
        name: str = module.name

        if isinstance(loader, ExtensionFileLoader):
            logger.debug("Adding module [%s] [EXTENSION]", name)
        elif isinstance(loader, (SourceFileLoader, SourcelessFileLoader)):
            filename = loader.get_filename(name)
            try:
                if (
                    isinstance(loader, SourcelessFileLoader)
                    or self.optimize == sys.flags.optimize
                ):
                    # Load Python bytecode
                    logger.debug("Adding module [%s] [BYTECODE]", name)
                    module.code = loader.get_code(name)
                else:
                    # Load & compile Python source code
                    logger.debug("Adding module [%s] [SOURCE]", name)
                    source = loader.get_source(name)
                    if source is not None:
                        module.code = loader.source_to_code(
                            source, filename, _optimize=self.optimize
                        )
            except ImportError as exc:
                module.error_exc = exc
                msg = f"{exc.__class__.__name__}: {exc.msg}"
                module.error_msg = msg
                logger.debug("%s in '%s' [%s]", msg, filename, name)
                module.in_import = False
                return False
            except SyntaxError as exc:
                module.error_exc = exc
                msg = f"{exc.__class__.__name__}: {exc.msg}"
                module.error_msg = msg
                logger.debug("%s in '%s' [%s]", msg, filename, name)
                module.in_import = False
                return False
        else:
            if module.file:
                filename = module.file.as_posix()
                msg = f"Unknown module loader in {filename!r}"
            else:
                msg = f"Unknown module loader for {module.name!r}"
            module.error_msg = msg
            logger.debug("%s [%s]", msg, module.name)
            module.in_import = False
            return False

        # Run custom hook for the module
        if module.hook:
            module.hook(self)

        # Make changes in code object
        module.code = code_object_replace_package(module)
        if self.replace_paths:
            module.code = self._replace_paths_in_code(module)

        # Scan the module code for import statements
        self._scan_code(module, deferred_imports)
        if module.code is None and module.stub_code is not None:
            self._scan_code(module, deferred_imports, code=module.stub_code)
        # using lazy loader
        if module.root.lazy and module.stub_code:
            self._scan_code(module, deferred_imports, code=module.stub_code)

        module.in_import = False
        return True

    def _load_module_code_builtins(
        self, module: Module, deferred_imports: DeferredList
    ) -> Module | None:
        # Run custom hook for the module
        if module.hook:
            module.hook(self)
        # Scan the module code for import statements
        self._scan_code(module, deferred_imports)
        module.in_import = False
        return module

    def _load_module_code_libraries(self, module: Module) -> None:
        """Add dynamic libraries (dependencies) of the package."""
        if module is module.root:
            for source, target in module.libs():
                self.lib_files.setdefault(source, target)
                # use include_files on windows
                if IS_WINDOWS:
                    self.include_files(source, target)
            if IS_WINDOWS and module.in_file_system == 0:
                # Save the directory "module.libs" to be used in __startup__
                # to simulate what is patched by delvewheel. Using zip file
                # the value of __file__ is in the zip, not in the "lib".
                dirs = module.libs_dirs()
                if dirs:
                    libs = self.constants_module.values.get("__LIBS__")
                    libs_dirs = (libs.split(os.pathsep) if libs else []) + dirs
                    self.add_constant("__LIBS__", os.pathsep.join(libs_dirs))

    def _load_module_from_file(
        self, name: str, filename: Path, deferred_imports: DeferredList
    ) -> Module | None:
        """Load the module from the filename."""
        loader: Loader | None = None

        ext = filename.suffix
        path = os.path.abspath(filename)
        if not ext or ext in SOURCE_SUFFIXES:
            loader = SourceFileLoader(name, path)
        elif ext in BYTECODE_SUFFIXES:
            loader = SourcelessFileLoader(name, path)
        elif ext in EXTENSION_SUFFIXES:
            loader = ExtensionFileLoader(name, path)

        module = self._add_module(name, filename=filename)
        module.loader = loader
        if not self._load_module_code(module, deferred_imports):
            exc: BaseException | None = module.error_exc
            msg = f"ImportError: Cannot import {path!r}"
            msg += " due to the previous error."
            if exc is not None:
                frame = fake_frame(path, getattr(exc, "lineno", 0))
                fake_tb = TracebackType(
                    None,
                    frame,
                    getattr(exc, "lineno", 0),
                    getattr(exc, "offset", 0),
                )
                traceback.print_exception(
                    type(exc), value=exc, tb=fake_tb, chain=False
                )
            elif module.error_msg is not None:
                msg = f"Error: {module.error_msg}\n{msg}"
            sys.exit(msg)
        return module

    def _missing_hook(self, caller: Module, module_name: str) -> None:
        """Run hook for missing module."""
        if module_name in DEFAULT_IGNORE_NAMES:
            return
        normalized_name = module_name.replace(".", "_")
        try:
            method = resolve_name(f"cx_Freeze.hooks:missing_{normalized_name}")
        except (AttributeError, ValueError):
            pass
        else:
            method(self, caller)
        if module_name not in caller.ignore_names:
            callers = self._bad_modules.setdefault(module_name, set())
            callers.add(caller.name)

    def _replace_paths_in_code(
        self, module: Module, code: CodeType | None = None
    ) -> CodeType | None:
        """Replace paths in the code as directed.

        Returns a new code object with the modified paths in place.
        """
        if code is None:
            code = module.code
        if code is None:
            return None

        # Prepare the new filename.
        original_filename = Path(code.co_filename)
        top_level_module: Module = module.root
        for search_value, replace_value in self.replace_paths:
            if search_value == "*":
                if top_level_module.file is None:
                    continue
                if top_level_module.path:
                    search_dir = top_level_module.file.parent.parent
                else:
                    search_dir = top_level_module.file.parent
            else:
                search_dir = Path(search_value)
            with suppress(ValueError):
                relative = original_filename.relative_to(search_dir)
                new_filename = replace_value / relative
                break
        else:
            new_filename = original_filename

        # Run on subordinate code objects from function & class definitions.
        consts = list(code.co_consts)
        for i, const in enumerate(consts):
            if isinstance(const, type(code)):
                consts[i] = self._replace_paths_in_code(
                    top_level_module, const
                )

        return code_object_replace(
            code, co_consts=consts, co_filename=os.fspath(new_filename)
        )

    def _scan_code(
        self,
        module: Module,
        deferred_imports: DeferredList,
        code: CodeType | None = None,
        top_level: bool = True,
    ) -> None:
        """Scan code, looking for imported modules.

        Also, keeping track of the constants that have been created in order
        to better tell which modules are truly missing.
        """
        if code is None:
            code = module.code
        if code is None:
            return

        imported_module = None
        for opc, args in scan_code(code):
            # import statement: attempt to import module
            if "import" in opc:
                name, relative_import_index, from_list = args
                if opc in ("__import__", "import_module"):
                    logger.debug("Scan code detected %s(%r)", opc, name)
                if name not in module.exclude_names:
                    imported_module = self._import_module(
                        name, deferred_imports, module, relative_import_index
                    )
                    if imported_module is not None and (
                        from_list
                        and from_list != ("*",)
                        and imported_module.path is not None
                    ):
                        self._ensure_from_list(
                            module,
                            imported_module,
                            from_list,
                            deferred_imports,
                        )

            # import * statement: copy all global names
            elif opc == "star" and top_level and imported_module is not None:
                module.global_names.update(imported_module.global_names)

            # store operation: track only top level
            elif opc == "store" and top_level:
                (name,) = args
                module.global_names.add(name)

        # Scan the code objects from function & class definitions
        if code.co_consts:
            for constant in code.co_consts:
                if isinstance(constant, CodeType):
                    self._scan_code(
                        module,
                        deferred_imports,
                        code=constant,
                        top_level=False,
                    )

    def add_alias(self, name: str, alias_for: str) -> None:
        """Add an alias for a particular module.

        When an attempt is made to import that module, the alias is used to
        import the actual name.
        """
        self.aliases[name] = alias_for
        # Import the module — if it was previously imported under its original
        # name — using the alias defined at this point.
        if name in self._modules:
            self._modules.pop(name)
            self.include_module(name)

    def add_constant(self, name: str, value: str) -> None:
        """Make available a constant in the module BUILD_CONSTANTS.

        BUILD_CONSTANTS is used in the initscripts.
        """
        self.constants_module.values[name] = value

    @cached_property
    def builtin_modules(self) -> Mapping[str, str]:
        """The built-in modules are based on the `freeze-core` build."""
        builtin_modules: dict[str, str] = {}
        frozen_file = resource_path(f"frozen/frozen-{SOABI}.json")
        if frozen_file:
            # using freeze-core 0.7.0+
            builtin_modules.update(json.loads(frozen_file.read_bytes()))
            builtin_modules.pop("__version__", None)
            return builtin_modules
        for name in sys.builtin_module_names:
            builtin_modules[name] = "built-in"
        if sys.version_info[:2] >= (3, 11):
            names = _imp._frozen_module_names()  # noqa: SLF001 # ty: ignore
            for name in names:
                builtin_modules[name] = "frozen"
        core_lib = resource_path("lib")
        if core_lib and core_lib.is_dir():
            # discard modules that exist in freeze-core 'lib'
            ext_suffix = get_config_var("EXT_SUFFIX")
            for file in core_lib.glob(f"*{ext_suffix}"):
                builtin_modules.pop(file.name.removesuffix(ext_suffix), None)
        return builtin_modules

    def exclude_dependent_files(self, filename: StrPath) -> None:
        """Exclude the dependent files of the named file.

        The files are excluded in the resulting frozen executable.
        """
        self.excluded_dependent_files.add(Path(filename))

    def exclude_module(self, name: str) -> None:
        """Exclude the named module and its submodules.

        The modules are excluded in the resulting frozen executable.
        """
        submodules = [
            mod for mod in self._modules if mod.startswith(f"{name}.")
        ]
        for submodule in submodules:
            self._modules.pop(submodule, None)
        self._modules[name] = None

    def excluded_submodules(self, name: str) -> set[str]:
        """Return the excluded set of submodules for the named module."""
        return {
            module_name
            for module_name, module in self._modules.items()
            if module_name.startswith(f"{name}.") and module is None
        }

    @cached_property
    def import_distributions(self) -> Mapping[str, Distribution]:
        """Return a mapping of imports to their distributions."""
        imports = {}
        dists = {d.name: d for d in distributions(path=self.path)}
        found = set()
        for import_name, packages in packages_distributions().items():
            for dist_name in set(packages):
                if dist_name not in dists:
                    # Normally setuptools _vendor packages are not found
                    # because they are excluded from the self.path.
                    continue
                if "." in dist_name:  # namespace package
                    imports[dist_name] = dists[dist_name]
                else:
                    imports[import_name] = dists[dist_name]
                found.add(dist_name)
        for dist_name in found:
            dists.pop(dist_name)
        if dists:
            # Even if the imports are not detected, include these distributions
            # as they will be useful for manual updates.
            imports.update(dists)
        return imports

    def include_file_as_module(
        self, path: StrPath, name: str | None = None
    ) -> Module | None:
        """Include the named file as a module in the frozen executable."""
        path = Path(path)
        if name is None:
            name = path.stem
        deferred_imports: DeferredList = []
        module = self._load_module_from_file(name, path, deferred_imports)
        if module is not None:
            parent = self._get_parent_by_name(name)
            if parent is not None:
                parent.global_names.add(module.name)
                module.parent = parent
        self._import_deferred_imports(deferred_imports)
        return module

    def include_files(
        self,
        source_path: StrPath,
        target_path: StrPath,
        copy_dependent_files: bool = True,
    ) -> None:
        """Include the files in the given directory in the target build."""
        self.included_files += process_path_specs([(source_path, target_path)])
        if not copy_dependent_files:
            self.exclude_dependent_files(source_path)

    def include_module(
        self, name: str, caller: Module | None = None
    ) -> Module | None:
        """Include the named module in the frozen executable."""
        # Remove the module *marked as excludes* from the module cache before
        # trying to import it, because includes has priority over excludes.
        if self._modules.get(name) is None:
            self._modules.pop(name, None)
        # Include the module.
        deferred_imports: DeferredList = []
        module = self._import_module(name, deferred_imports, caller)
        self._import_deferred_imports(deferred_imports, skip_in_import=True)
        return module

    def include_package(
        self, name: str, caller: Module | None = None
    ) -> Module | None:
        """Include the named package and any submodules.

        The package is excluded in the resulting frozen executable.
        """
        # Remove the package *marked as excludes* from the module cache before
        # trying to import it, because includes has priority over excludes.
        if self._modules.get(name) is None:
            self._modules.pop(name, None)
        # Include the package.
        deferred_imports: DeferredList = []
        module = self._import_module(name, deferred_imports, caller)
        if module and module.path:
            self._import_all_sub_modules(module, deferred_imports)
        self._import_deferred_imports(deferred_imports, skip_in_import=True)
        return module

    @cached_property
    def modules(self) -> list[Module]:
        """Sorted list of modules expected in the frozen executable."""
        valid_modules = {
            module for module in self._modules.values() if module is not None
        }
        valid_modules -= set(self.namespaces)
        builtin = {
            module
            for module in valid_modules
            if module.name in self.builtin_modules
        }
        if sys.version_info[:2] < (3, 11):
            builtin |= {
                module
                for module in valid_modules
                if module.file and module.file.name == "frozen"
            }
        valid_modules -= builtin
        return sorted(valid_modules, key=lambda module: module.name)

    @property
    def optimize(self) -> int:
        """Value of optimize flag propagated according to the user's choice."""
        return self._optimize_flag

    @optimize.setter
    def optimize(self, value: int) -> None:
        # The value of optimize is checked in '.command.build_exe' or '.cli'.
        self._optimize_flag = value if 0 <= value <= 2 else sys.flags.optimize

    def report_missing_modules(self) -> None:
        """Display a list of modules that weren't found."""
        if self._bad_modules:
            print("Missing modules:")
            for name in sorted(self._bad_modules):
                callers = sorted(self._bad_modules[name])
                print(f"? {name} imported from", ", ".join(callers))
            print("This is not necessarily a problem", end=" - ")
            print("the modules may not be needed on this platform.\n")

    def zip_include_files(
        self,
        source_path: StrPath,
        target_path: StrPath | None = None,
    ) -> None:
        """Include files or all of the files in a directory to the zip file."""
        self.zip_includes.extend(
            process_path_specs([(source_path, target_path)])
        )


def fake_frame(filename: str, lineno: int) -> FrameType:
    linecache.updatecache(filename)
    res = {}
    source = ("\n" * max(0, lineno - 1)) + "f=inspect.currentframe()"
    code = compile(source, filename, "exec")
    exec(code, {"inspect": inspect}, res)  # noqa:S102
    return res["f"]
