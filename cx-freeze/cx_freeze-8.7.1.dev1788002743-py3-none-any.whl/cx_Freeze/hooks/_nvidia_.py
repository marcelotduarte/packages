"""Hooks triggered by finder when nvidia package is included."""

from __future__ import annotations

from importlib.machinery import SourceFileLoader
from textwrap import dedent
from typing import TYPE_CHECKING

from cx_Freeze._compat import IS_MACOS, IS_MINGW, IS_WINDOWS
from cx_Freeze.module import Module, ModuleHook

if TYPE_CHECKING:
    from cx_Freeze.finder import ModuleFinder


__all__ = ["Hook"]


class Hook(ModuleHook):
    """The Hook class for nvidia."""

    def nvidia(self, finder: ModuleFinder, module: Module) -> None:
        """Include the cuda libraries as fixed libraries."""
        if IS_MINGW or IS_WINDOWS:
            extension = "*.dll"
        elif IS_MACOS:
            extension = "*.dylib"
        else:
            extension = "*.so*"

        if module.file is None:  # to make ty happy
            return
        source_lib = module.file.parent
        if source_lib.exists():
            target_lib = f"lib/{source_lib.name}"
            for source in source_lib.glob(f"*/lib/{extension}"):
                library = source.relative_to(source_lib).as_posix()
                finder.lib_files[source] = f"{target_lib}/{library}"

        # fix for issue #2682
        patch = f"""
            def _cxfreeze_patch():
                import ctypes
                import sys
                from pathlib import Path

                source_lib = Path(sys.prefix, "lib", "nvidia")
                for source in source_lib.glob("*/lib/{extension}"):
                    ctypes.CDLL(source)
            _cxfreeze_patch()
        """
        loader = module.loader
        if not isinstance(loader, SourceFileLoader):
            return
        source_code = loader.get_source(module.name)
        if source_code is None:
            return
        module.code = loader.source_to_code(
            source_code + dedent(patch),
            loader.get_filename(module.name),
            _optimize=finder.optimize,
        )
