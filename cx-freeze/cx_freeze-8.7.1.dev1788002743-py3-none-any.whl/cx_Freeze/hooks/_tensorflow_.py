"""Hooks triggered by finder when tensorflow package is included."""

from __future__ import annotations

from importlib.machinery import SourceFileLoader
from typing import TYPE_CHECKING

from cx_Freeze._compat import IS_MINGW, IS_WINDOWS
from cx_Freeze.module import Module, ModuleHook

if TYPE_CHECKING:
    from cx_Freeze.finder import ModuleFinder


__all__ = ["Hook"]


class Hook(ModuleHook):
    """The Hook class for tensorflow."""

    def tensorflow(self, finder: ModuleFinder, module: Module) -> None:
        """Include modules and files required by tensorflow.

        Tested in Windows and Linux.
        """
        if module.file is None:  # to make ty happy
            return
        module_path = module.file.parent
        site_packages_path = module_path.parent

        # implicitly loaded packages
        finder.include_package("tensorboard")
        finder.include_package("tensorflow.compiler")
        finder.include_package("tensorflow.python")

        # support for plugins
        source_path = site_packages_path / "tensorflow-plugins"
        if source_path.is_dir():
            pattern = "*.dll" if (IS_WINDOWS or IS_MINGW) else "*.so"
            for source in source_path.rglob(pattern):  # type: Path
                target = "lib" / source.relative_to(site_packages_path)
                finder.include_files(source, target)

        # patch the source code to search the correct directory
        loader = module.loader
        if not isinstance(loader, SourceFileLoader):
            return
        source_code = loader.get_source(module.name)
        if source_code is None:
            return
        source_code = source_code.replace(
            "_site_packages_dirs = []",
            "_site_packages_dirs = [_os.path.join(_sys.prefix, 'lib')]",
        )
        source_code = source_code.replace(
            "_current_file_location = ",
            "_current_file_location = __file__.replace('library.zip', '.')  #",
        )
        module.code = loader.source_to_code(
            source_code,
            loader.get_filename(module.name),
            _optimize=finder.optimize,
        )

        # installed version of tensorflow is a variant?
        if module.distribution is None:
            for name in (
                "tensorflow-aarch64",
                "tensorflow-cpu",
                "tensorflow-cpu-aws",
                "tensorflow-gpu",
                "tensorflow-intel",
                "tensorflow-macos",
                "tensorflow-rocm",
            ):
                module.update_distribution(name)
                if module.distribution is not None:
                    break

        # remove run-time warning
        # WARNING:tensorflow:AutoGraph is not available in this environment:...
        source_path = site_packages_path / "tensorflow/python/autograph"
        for source in source_path.rglob("*.py"):  # type: Path
            target = "lib" / source.relative_to(site_packages_path)
            finder.include_files(source, target)
        finder.exclude_module("tensorflow.python.autograph")
