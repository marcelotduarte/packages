"""Hooks triggered by finder when pkg_resources package is included."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from cx_Freeze.module import Module, ModuleHook

if TYPE_CHECKING:
    from cx_Freeze.finder import ModuleFinder


__all__ = ["Hook"]


class Hook(ModuleHook):
    """The Hook class for pkg_resources.

    Since cx_Freeze 8.5.0, setuptools>=78.1.1 is used.
    """

    def pkg_resources(self, finder: ModuleFinder, module: Module) -> None:
        """Import modules from setuptools._vendor."""
        finder.exclude_module("pkg_resources.tests")
        failed = [
            name
            for name in ("jaraco.text", "packaging", "platformdirs")
            if finder.include_module(name, module) is None
        ]
        if not failed:
            return
        if module.file is None:  # to satisfy ty
            return
        vendor_dir = module.file.parent.parent / "setuptools" / "_vendor"
        if vendor_dir.is_dir():
            finder.path.append(os.path.normpath(vendor_dir))
            for name in failed:
                pos = name.rfind(".")
                if pos > 0:
                    parent_name = name[:pos]
                    finder.include_module(parent_name)
                finder.include_module(name, module)
            finder.path.pop()
