"""Hooks triggered by finder when PyQt5 package is included."""

from __future__ import annotations

from importlib import resources
from importlib.machinery import SourceFileLoader
from textwrap import dedent
from typing import TYPE_CHECKING

from cx_Freeze._compat import IS_MACOS, IS_MINGW, IS_WINDOWS
from cx_Freeze.hooks.qthooks import QtHook, copy_qt_files

if TYPE_CHECKING:
    from cx_Freeze.finder import ModuleFinder
    from cx_Freeze.module import Module

__all__ = ["Hook"]


class Hook(QtHook):
    """The Hook class for PyQt5."""

    def __init__(self, module: Module) -> None:
        super().__init__(module)
        self.name = "qt"

    def qt(self, finder: ModuleFinder, module: Module) -> None:
        """Inject code in PyQt5 to locate and load plugins and resources.

        Also, this fixes issues with conda-forge versions.
        """
        distribution = module.distribution
        environment = (distribution and distribution.installer) or "pip"
        # Activate the optimized mode by default in pip environments
        if environment == "pip":
            if module.name in finder.zip_exclude_packages:
                print(f"WARNING: zip_exclude_packages={module.name} ignored.")
            if module.name in finder.zip_include_packages:
                print(f"WARNING: zip_include_packages={module.name} ignored.")
            module.in_file_system = 2

        # Include a module that inject an optional debug code
        package = resources.files(__package__ or "cx_Freeze.hooks._pyqt5_")
        finder.include_file_as_module(
            str(package / "_debug.py"), "PyQt5._cx_freeze_debug"
        )

        # Include a resource with qt.conf (Prefix = lib/PyQt5) for conda-forge
        if environment == "conda":
            finder.include_file_as_module(
                str(package / "_resource.py"), "PyQt5._cx_freeze_resource"
            )

        # Include an optional qt.conf to be used by QtWebEngine (Prefix = ..)
        copy_qt_files(finder, "PyQt5", "LibraryExecutablesPath", "qt.conf")

        # Inject code to the end of init
        patch = f"""
            # cx_Freeze patch start
            import os, sys

            prefix = sys.prefix
            qt_root_dir = os.path.join(prefix, "lib", "PyQt5")
            try:
                from PyQt5 import QtCore
            except ImportError:
                if {IS_MINGW or IS_WINDOWS}:
                    bin_dir = os.path.join(qt_root_dir, "Qt5", "bin")
                    if os.path.isdir(bin_dir):
                        os.add_dll_directory(bin_dir)
                        from PyQt5 import QtCore
            if {environment == "conda"}:  # conda-forge linux, macos, windows
                import PyQt5._cx_freeze_resource
            elif {IS_MACOS}:  # macos using 'pip install pyqt5'
                # Support for QtWebEngine (bdist_mac differs from build_exe)
                helpers = os.path.join(os.path.dirname(prefix), "Helpers")
                if not os.path.isdir(helpers):
                    helpers = os.path.join(prefix, "share")
                os.environ["QTWEBENGINEPROCESS_PATH"] = os.path.join(
                    helpers,
                    "QtWebEngineProcess.app/Contents/MacOS/QtWebEngineProcess"
                )
                os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = "--single-process"
            else:
                # Support for QtWebEngine (linux and windows using pip)
                os.environ["QTWEBENGINE_DISABLE_SANDBOX"] = "1"
            # With PyQt5 5.15.4, if the folder name contains non-ascii
            # characters, the libraryPaths returns empty.
            # Prior to this version, this doesn't happen.
            plugins_dir = os.path.join(qt_root_dir, "Qt5", "plugins")  # 5.15.4
            if not os.path.isdir(plugins_dir):
                plugins_dir = os.path.join(qt_root_dir, "Qt", "plugins")
            if not os.path.isdir(plugins_dir):
                plugins_dir = os.path.join(qt_root_dir, "plugins")
            if os.path.isdir(plugins_dir):
                QtCore.QCoreApplication.addLibraryPath(
                    plugins_dir.replace(os.path.sep, os.path.altsep or "/")
                )
            import PyQt5._cx_freeze_debug
            # cx_Freeze patch end
        """
        loader = module.loader
        if not isinstance(loader, SourceFileLoader):
            return
        source_code = loader.get_source(module.name)
        if source_code is None:
            return
        if environment == "conda":
            source_code = ""
        else:
            source_code = loader.get_source(module.name) or ""
        module.code = loader.source_to_code(
            source_code + dedent(patch),
            loader.get_filename(module.name),
            _optimize=finder.optimize,
        )

    def qt_qtwebenginecore(self, finder: ModuleFinder, module: Module) -> None:
        """Include module dependency and QtWebEngineProcess files."""
        super().qt_qtwebenginecore(finder, module)
        parent = module.parent or module.root
        distribution = parent.distribution
        environment = (distribution and distribution.installer) or "pip"
        if IS_MACOS and environment == "pip":
            # duplicate resource files
            for source, target in finder.included_files[:]:
                if any(
                    filter(
                        source.match, ("Resources/*.pak", "Resources/*.dat")
                    )
                ):
                    finder.include_files(
                        source,
                        target.parent.parent / target.name,
                        copy_dependent_files=False,
                    )
