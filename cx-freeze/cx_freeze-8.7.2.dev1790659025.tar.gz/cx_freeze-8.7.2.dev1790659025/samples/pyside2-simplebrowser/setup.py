"""Creates an executable using PySide2 WebEngineWidgets.

This also demonstrates how to use excludes to get minimal package size.

simplebrowser.py is the "PySide2 WebEngineWidgets Example".

Run the build process by running the command 'python setup.py build'

If everything works well you should find a subdirectory in the build
subdirectory that contains the files needed to run the application
"""

import os

from cx_Freeze import Executable, setup

options = {
    "build_exe": {
        # exclude packages that are not really needed
        "excludes": ["tkinter", "email", "http", "xml"]
    },
    "bdist_mac": {
        "custom_info_plist": None,  # Set this to use a custom info.plist file
        "codesign_entitlements": os.path.join(
            os.path.dirname(__file__), "codesign-entitlements.plist"
        ),
        # Set this to enable signing with custom identity
        # (replaces adhoc signature)
        "codesign_identity": None,
        # Ensure codesign uses 'hardened runtime'
        "codesign_options": "runtime",
        # Enable to get more verbose logging regarding codesign
        "codesign_verify": False,
        # Enable to get more verbose logging regarding codesign
        "spctl_assess": False,
    },
}

executables = [
    Executable(
        "simplebrowser.py", target_name="test_simplebrowser", base="gui"
    )
]

setup(
    name="simplebrowser",
    version="7.2",
    description="Sample cx_Freeze PySide2 simplebrowser script",
    options=options,
    executables=executables,
)
