"""Fixtures."""

from __future__ import annotations

import argparse
import errno
import io
import json
import os
import re
import string
import subprocess
import sys
import sysconfig
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass
from pathlib import Path
from shutil import copytree, ignore_patterns, rmtree, which
from textwrap import dedent
from typing import TYPE_CHECKING, Any, TypeAlias

import pytest
from filelock import BaseFileLock, FileLock
from packaging.requirements import InvalidRequirement, Requirement

if sys.version_info[:2] >= (3, 11):
    import tomllib
else:
    from setuptools.compat.py310 import tomllib

if TYPE_CHECKING:
    from collections.abc import Sequence
    from os import PathLike
    from types import GeneratorType

    StrPath: TypeAlias = str | PathLike[str]

# copied from cx_Freeze._compat
PLATFORM = sysconfig.get_platform()
PYTHON_VERSION = sysconfig.get_python_version()
ABI_THREAD = sysconfig.get_config_var("abi_thread") or ""
BUILD_EXE_DIR = Path(f"build/exe.{PLATFORM}-{PYTHON_VERSION}{ABI_THREAD}")
EXE_SUFFIX = sysconfig.get_config_var("EXE")

IS_CONDA = Path(sys.prefix, "conda-meta").is_dir()
IS_MINGW = PLATFORM.startswith("mingw")
HAVE_UV = which("uv") is not None

HERE = Path(__file__).resolve().parent
SAMPLES_DIR = HERE.parent / "samples"


class FakeLock(BaseFileLock):
    """Fake lock."""

    def _acquire(self) -> None:
        pass

    def _release(self) -> None:
        pass

    @property
    def is_locked(self) -> bool:
        return True


@dataclass
class PackageData:
    """PackageData."""

    name: str
    version: str
    editable_project_location: str | None = None

    @property
    def normalized_name(self) -> str:
        return normalize(self.name)

    @property
    def spec(self) -> str:
        if self.name == self.normalized_name:
            return f"{self.name}=={self.version}"
        return f"{self.normalized_name}=={self.version}"


class TempPackage:
    """Base class to create package in temporary path."""

    def __init__(
        self,
        request: pytest.FixtureRequest,
        tmp_path_factory: pytest.TempPathFactory,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        self.request = request
        self.tmp_path_factory = tmp_path_factory
        self.monkeypatch = monkeypatch

        monkeypatch.setenv("PYTHONUNBUFFERED", "1")

        # determine the root of pytest tmp_path
        self._root: Path = tmp_path_factory.getbasetemp().parent
        self._worker: str = os.environ.get("PYTEST_XDIST_WORKER", "master")
        if self._worker != "master":
            # using xdist, the root is one level up
            self._root = self._root.parent

        # environment
        sysexe = Path(sys.executable)
        prefix = Path(sys.prefix)
        self.prefix: Path = prefix
        self.python: Path = sysexe
        self.system_prefix: Path = prefix
        self.system_python = sysexe
        self.relative_bin: str = sysexe.parent.relative_to(prefix).as_posix()
        self.relative_site: str = (
            Path(pytest.__file__).parent.parent.relative_to(prefix).as_posix()
        )

        # make a temporary directory and set it as current
        if hasattr(request, "function"):
            name: str = request.function.__name__
        else:
            name = request.node.name.replace(".py", "")
        self._name = name
        self.path: Path = tmp_path_factory.mktemp(name, numbered=True)
        self.system_path: Path = Path(os.getcwd())
        os.chdir(self.path)

        # lock files
        self.backend: str = request.config.option.venv_backend
        if self.backend == "mingw":
            self._lock = FileLock("/var/lib/pacman/db.lck")
        elif self.backend == "pip":
            self._lock = FileLock(self.prefix / ".lock")
        else:
            # conda and uv have internal lock
            self._lock = FakeLock(self.prefix / ".lock")
        self._isolated = False

        # packages mapping
        self.map_package_to_conda: dict[str, str] = {
            "cx-logging": "cx_logging",
            "cx_Logging": "cx_logging",
            "cx-freeze": "cx_freeze",
            "cx_Freeze": "cx_freeze",
            "lief": "py-lief",
        }
        self.map_package_to_mingw: dict[str, str] = {
            "cx_logging": "python-cx-logging",
            "cx_Logging": "python-cx-logging",
            "cx_freeze": "python-cx-freeze",
            "cx_Freeze": "python-cx-freeze",
        }

    def create(self, source: str) -> None:
        """Create package in temporary path, based on source."""
        buf = []
        filename: Path | None = None
        for line in [*source.splitlines(), "EOF"]:
            if not line.startswith(tuple(string.ascii_letters)):
                buf.append(line)
            else:
                if filename:
                    buf.append("")
                    filename.parent.mkdir(parents=True, exist_ok=True)
                    filename.write_bytes(
                        dedent("\n".join(buf)).encode("utf_8")
                    )
                    buf = []
                filename = self.path / line.strip()

    def create_from_sample(self, sample: str) -> None:
        """Create package in path, based on sample."""
        copytree(
            SAMPLES_DIR / sample,
            self.path,
            symlinks=True,
            ignore=ignore_patterns("build", "dist", ".venv", "wheelhouse"),
            dirs_exist_ok=True,
        )

    def executable(self, base_name: str) -> Path:
        return self.path / BUILD_EXE_DIR / f"{base_name}{EXE_SUFFIX}"

    def executable_in_dist(self, base_name: str) -> Path:
        return self.path / "dist" / f"{base_name}{EXE_SUFFIX}"

    def freeze(
        self,
        command: Sequence[str] | Path | None = None,
        cwd: StrPath | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> pytest.RunResult:
        """Execute the command to freeze the current test sample.

        The command can be specified in 'command' argument, or read from the
        file named 'command', or a default command is used.
        """
        __tracebackhide__ = True
        if command is None:
            command_file = self.path / "command"
            if command_file.exists():
                command = command_file.read_bytes().decode()
            elif self.path.joinpath("pyproject.toml").exists():
                command = "cxfreeze build"
            else:
                command = "python setup.py build"
        elif isinstance(command, Path):
            command = os.fspath(command)
        command = (
            command.split() if isinstance(command, str) else list(command)
        )

        python_path = env and env.get("PYTHONPATH")  # pop
        if python_path:
            if "build_exe" not in command and "build" in command:
                command.append("build_exe")
            try:
                build_exe = command.index("build_exe")
            except ValueError:
                build_exe = len(command)
            if build_exe > 0:
                command.insert(build_exe + 1, f"--include-path={python_path}")

        with self._lock:
            return self.run(command, cwd=cwd, env=env, timeout=timeout)

    def run(
        self,
        command: Sequence | Path,
        cwd: StrPath | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
        *,
        raise_on_timeout: bool = True,
    ) -> pytest.RunResult:
        """Execute a command, specified in 'command'."""
        __tracebackhide__ = True
        if isinstance(command, Path):
            command = [os.fspath(command)]
        command = (
            command.split() if isinstance(command, str) else list(command)
        )

        if command[0] == "cxfreeze":
            cxfreeze = which("cxfreeze", path=self.prefix / self.relative_bin)
            if cxfreeze:
                command[0] = cxfreeze
            else:
                command = ["python", "-m", "cx_Freeze", *command[1:]]

        if command[0] == "conda":
            conda = which("conda")
            if conda:
                command[0] = conda

        if command[0] == "pip":
            pip = which("pip", path=self.prefix / self.relative_bin)
            if pip:
                command[0] = pip
            else:
                command = ["python", "-m", "pip", *command[1:]]

        if command[0] == "python":
            command[0] = os.fspath(self.python)

        cwd = os.fspath(self.path if cwd is None else cwd)
        try:
            process = subprocess.run(
                command,
                capture_output=True,
                check=False,
                cwd=cwd,
                env=env,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            if raise_on_timeout:
                raise
            returncode = errno.ETIMEDOUT
            stdout = exc.output or ""
            stderr = exc.stderr or ""
        else:
            returncode = process.returncode
            stdout = process.stdout or ""
            stderr = process.stderr or ""

        stdout = stdout.decode() if isinstance(stdout, bytes) else str(stdout)
        if isinstance(stderr, bytes):
            stderr = stderr.decode()
        # print result as debug information if not using xdist or on error
        if self._worker == "master" or returncode != 0:
            print(stdout, flush=True)
            print(stderr, file=sys.stderr)

        return pytest.RunResult(
            returncode, stdout.splitlines(), stderr.splitlines(), 0
        )

    def install(
        self,
        packages: str | list[str],
        *,
        binary: bool = True,
        deps: bool = True,
        index: bool | StrPath | None = None,
        isolated: bool = True,
        prerelease: bool = False,
    ) -> pytest.RunResult | None:
        """Install required packages for the test."""
        if isinstance(packages, str):
            packages = [packages]
        if not packages:
            return None

        with self._lock:
            names = []
            names_and_specs = []
            for package in packages:
                req = Requirement(package)
                if req.marker is not None and not req.marker.evaluate():
                    continue
                names.append(req.name)
                names_and_specs.append(f"{req.name}{req.specifier!s}")
            if not names:
                return None
            if self.backend == "conda":
                return self._install_conda(
                    names_and_specs, deps=deps, index=index
                )
            if self.backend == "mingw":
                return self._install_mingw(names)
            return self._install_pip(
                names_and_specs,
                binary=binary,
                deps=deps,
                index=index,
                isolated=isolated,
                prerelease=prerelease,
            )

    def install_dependencies(self, pyproject: Path | None = None) -> None:
        """Install dependencies for the test.

        The default is to read from pyproject.toml.
        """
        project_data = self._get_project(pyproject)
        prerelease = self.request.config.option.venv_prerelease
        self.install(project_data["dependencies"], prerelease=prerelease)

    def install_editable(
        self,
        packages: str | list[str],
        *,
        deps: bool = True,
        index: bool | StrPath | None = None,
        isolated: bool = True,
        prerelease: bool = True,
    ) -> pytest.RunResult | None:
        """Install editable packages for the test."""
        if isinstance(packages, str):
            packages = [packages]
        if not packages:
            return None

        # check backend values
        if self.backend == "mingw":
            backend = "pip"
            # ensure that 'pip' is installed
            self.install("pip")
        else:
            backend = self.backend

        with self._lock:
            editables = [f"-e{package}" for package in packages]
            if not editables:
                return None
            if self.backend == "conda":
                # conda>=26.5 supports conda-pypi
                # TODO: conda config --append channels conda-pypi
                return self._install_conda_editable(editables)
            return self._install_pip(
                editables,
                backend=backend,
                binary=False,
                deps=deps,
                index=index,
                isolated=isolated,
                prerelease=prerelease,
            )

    def _get_project(self, pyproject: Path | None = None) -> dict[str, Any]:
        """Get project metadata (specified in the pyproject.toml)."""
        if pyproject is None:
            pyproject = self.path / "pyproject.toml"
        if pyproject.is_file():
            with pyproject.open("rb") as f:
                data = tomllib.load(f)
        else:
            data = {}
        data.setdefault("project", {})
        data["project"].setdefault("name", "undefined")
        data["project"].setdefault("dependencies", [])
        return data["project"]

    def _get_installed_packages(
        self, prefix: StrPath | None = None, python: StrPath | None = None
    ) -> list[PackageData]:
        """Get installed packages."""
        if prefix is None:
            prefix = self.prefix
        if python is None:
            python = self.python
        if self.backend == "conda":
            cmd = f"conda list --json -p {prefix} -q"
        elif self.backend == "uv":
            cmd = f"uv pip list --format=json --python={python} -q"
        else:
            cmd = f"{python} -m pip list --format=json"
        result = self.run(cmd, cwd=self.system_path)
        full_list: list[dict[str, str]] = json.loads(str(result.stdout))
        installed = []
        for package in full_list:
            editable_location = package.get("editable_project_location")
            if self.backend == "conda":
                if not package.get("build_string", "").startswith("py"):
                    continue
                if (
                    package.get("base_url") is None
                    and package.get("channel") == "<unknown>"
                ):
                    editable_location = self.system_path.as_posix()
            data = PackageData(
                package["name"], package["version"], editable_location
            )
            installed.append(data)
        return installed

    def _install_conda(
        self,
        packages: list[str],
        *,
        deps: bool = True,
        index: bool | StrPath | None = None,
    ) -> pytest.RunResult:
        for i, package in enumerate(packages):
            try:
                req = Requirement(package)
            except InvalidRequirement:
                break
            if req.marker is not None and not req.marker.evaluate():
                continue
            try:
                conda_name = self.map_package_to_conda[req.name]
            except KeyError:
                continue
            if req.specifier:
                conda_name = f"{conda_name}{req.specifier!s}"
            packages[i] = conda_name

        packages: str = " ".join(packages)
        cmd = f"conda install -p {self.prefix} -q -y -S {packages}"
        if deps is False:
            cmd = f"{cmd} --no-deps"
        if index is False:
            cmd = f"{cmd} -c conda-forge"
        elif isinstance(index, str):
            cmd = f"{cmd} -c {index}"
        elif isinstance(index, Path):
            cmd = f"{cmd} -c {index} --strict-channel-priority"
        result = self.run(cmd, cwd=self.system_path)
        if result.ret > 0:
            raise ModuleNotFoundError(packages) from None
        return result

    def _install_conda_editable(self, packages: list[str]) -> pytest.RunResult:
        editables = []
        for package in packages:
            if package.startswith("-e"):
                editables.append(package)
            else:
                editables.append(f"-e{package}")
        installed = self._get_installed_packages()
        packages: str = " ".join(packages)
        cmd = f"conda pypi install -p {self.prefix} -q -y {packages}"
        result = self.run(cmd, cwd=self.system_path)
        if result.ret > 0:
            raise ModuleNotFoundError(packages) from None
        try:
            return result
        finally:
            names = [pkg.name for pkg in installed]
            name_to_remove = None
            for pkg in self._get_installed_packages():
                name = pkg.name
                if name not in names:
                    name_to_remove = name
                    break
            if name_to_remove:

                def _conda_remove_editable() -> None:
                    cmd = (
                        f"conda remove {name_to_remove} -p {self.prefix}"
                        " -q -y --force --offline"
                    )
                    with io.StringIO() as f, redirect_stdout(f):
                        self.run(cmd, cwd=self.system_path)

                self.request.config.add_cleanup(_conda_remove_editable)

    def _install_mingw(self, packages: list[str]) -> pytest.RunResult:
        MINGW_PACKAGE_PREFIX = os.environ["MINGW_PACKAGE_PREFIX"]
        for i, pkg in enumerate(packages):
            try:
                package = self.map_package_to_mingw[pkg]
            except KeyError:
                package = f"python-{pkg}"
            packages[i] = f"{MINGW_PACKAGE_PREFIX}-{package}"
        packages: str = " ".join(packages)
        cmd = f"pacman -S --needed --noconfirm --quiet {packages}"
        result = self.run(cmd, cwd=self.system_path)
        if result.ret > 0:
            raise ModuleNotFoundError(packages) from None
        return result

    def _install_pip(
        self,
        packages: list[str],
        *,
        backend: str | None = None,
        binary: bool = True,
        deps: bool = True,
        index: bool | StrPath | None = None,
        isolated: bool = False,
        prerelease: bool = False,
    ) -> pytest.RunResult:
        if backend is None:
            backend = self.backend
        # "uv pip install --prefix" install the package in the new prefix as a
        # fake venv, even if the package already exists in the real venv.
        # With "pip" if the package exists, it will be uninstalled and then
        # installed on the fake venv. To get around this situation, save a list
        # of packages that should be restored after the installation process.
        saved = []
        if isolated and self.backend == "pip":
            names = []
            for package in packages:
                try:
                    req = Requirement(package)
                except InvalidRequirement:
                    continue  # ignore, for example, editable package
                names.append(normalize(req.name))
            if names:
                installed = self._get_installed_packages()
                saved.extend(
                    [pkg.spec for pkg in installed if pkg.name in names]
                )

        packages: str = " ".join(packages)
        if backend == "uv":
            cmd = f"uv pip install --python={self.python} {packages}"
            if binary:
                cmd = f"{cmd} --no-build"
            if prerelease:
                cmd = f"{cmd} --prerelease=allow --reinstall"
        else:
            cmd = f"pip install {packages}"
            if binary:
                cmd = f"{cmd} --prefer-binary"
            if prerelease:
                cmd = f"{cmd} --pre --force-reinstall"
        if deps is False:
            cmd = f"{cmd} --no-deps"
        if index is False:
            cmd = f"{cmd} --no-index"
        elif isinstance(index, str):
            cmd = f"{cmd} --index {index}"
        elif isinstance(index, Path):
            cmd = f"{cmd} -f {index} --no-index"
        if isolated:
            cmd = f"{cmd} --prefix={self.path / '.tmp_prefix'}"
        else:
            cmd = f"{cmd} --prefix={self.prefix}"
        result = self.run(cmd, cwd=self.system_path)
        if result.ret > 0:
            raise ModuleNotFoundError(packages) from None

        if saved:
            self._install_pip(saved, isolated=False)

        if isolated and not self._isolated:
            tmp_site = os.path.normpath(
                self.path / ".tmp_prefix" / self.relative_site
            )
            self.monkeypatch.setenv("PYTHONPATH", tmp_site)
            self.monkeypatch.syspath_prepend(tmp_site)
            self._isolated = isolated
        return result

    def cleanup(self) -> None:
        os.chdir(self.system_path)

        # remove build directory (to reduce disk usage)
        if not self.request.config.option.venv_keep_build:
            build_dir: Path = self.path / "build"
            rmtree(build_dir, ignore_errors=True)

        # remove temporary prefix (to reduce disk usage)
        if not self.request.config.option.venv_keep_prefix:
            tmp_prefix = self.path / ".tmp_prefix"
            rmtree(tmp_prefix, ignore_errors=True)


class TempPackageVenv(TempPackage):
    """Base class to create package in temporary path using venv."""

    def __init__(
        self,
        request: pytest.FixtureRequest,
        tmp_path_factory: pytest.TempPathFactory,
        monkeypatch: pytest.MonkeyPatch | None = None,
    ) -> None:
        if monkeypatch is None:
            monkeypatch = pytest.MonkeyPatch()
        super().__init__(request, tmp_path_factory, monkeypatch)

        # activate the venv
        self.venv_prefix = self.prefix
        self.venv_python = self.python
        self._v_lock = None
        self._venv()

    def create(self, source: str) -> None:
        super().create(source)
        self.install_system_dependencies()
        # install dependencies
        venv_marker = self.request.node.get_closest_marker(name="venv")
        install_deps = venv_marker.kwargs.get("install_dependencies", True)
        if install_deps:
            self.install_dependencies()
        self.unlock()

    def create_from_sample(self, sample: str) -> None:
        super().create_from_sample(sample)
        self.install_system_dependencies()
        # install dependencies
        venv_marker = self.request.node.get_closest_marker(name="venv")
        install_deps = venv_marker.kwargs.get("install_dependencies", True)
        if install_deps:
            self.install_dependencies()
        self.unlock()

    def freeze(
        self,
        command: Sequence[str] | Path | None = None,
        cwd: StrPath | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> pytest.RunResult:
        if self.backend in ("conda", "pip", "uv"):
            self.prefix = self.venv_prefix
            self.python = self.venv_python
            try:
                return super().freeze(command, cwd, env, timeout)
            finally:
                self.prefix = self.system_prefix
                self.python = self.system_python
        # PYTHONPATH is the key here
        if env is None:
            env = os.environ.copy()
        prefix = self.venv_prefix or self.prefix
        venv_site = os.path.normpath(prefix / self.relative_site)
        env["PYTHONPATH"] = venv_site
        return super().freeze(command, cwd, env, timeout)

    def install(
        self,
        packages: str | list[str],
        *,
        binary: bool = True,
        deps: bool = True,
        index: bool | StrPath | None = None,
        isolated: bool = False,  # noqa: ARG002
        prerelease: bool = False,
    ) -> pytest.RunResult | None:
        # install in the venv prefix
        self.prefix = self.venv_prefix
        self.python = self.venv_python
        try:
            return super().install(
                packages,
                binary=binary,
                deps=deps,
                index=index,
                isolated=False,
                prerelease=prerelease,
            )
        finally:
            self.prefix = self.system_prefix
            self.python = self.system_python

    def install_editable(
        self,
        packages: str | list[str],
        *,
        deps: bool = True,
        index: bool | StrPath | None = None,
        isolated: bool = False,  # noqa: ARG002
        prerelease: bool = False,
    ) -> pytest.RunResult | None:
        # install in the venv prefix
        self.prefix = self.venv_prefix
        self.python = self.venv_python
        try:
            return super().install_editable(
                packages,
                deps=deps,
                index=index,
                isolated=False,
                prerelease=prerelease,
            )
        finally:
            self.prefix = self.system_prefix
            self.python = self.system_python

    def install_system_dependencies(self) -> None:
        """Install system dependencies for the project.

        The dependencies are read from pyproject.toml.
        """
        if self.backend not in ("conda", "pip", "uv"):
            return
        pyproject = self.system_path / "pyproject.toml"
        project_data = self._get_project(pyproject)
        project_name = normalize(project_data["name"])
        # filter 'required' dependencies from pyproject.toml
        dependencies = project_data["dependencies"]
        required = [project_name]
        for package in dependencies:
            try:
                req = Requirement(package)
            except InvalidRequirement:
                continue
            if req.marker is not None and not req.marker.evaluate():
                continue
            required.append(normalize(req.name))
        required.sort()

        # get installed packages in the host environment
        # compare them with the 'required' dependencies from pyproject.toml
        # check for editable packages in development environment
        packages = []
        editables = []
        project_is_editable = False
        for pkg in self._get_installed_packages():
            if pkg.normalized_name in required:
                if pkg.editable_project_location is not None:
                    editables.append(pkg.editable_project_location)
                    if pkg.normalized_name == project_name:
                        project_is_editable = True
                elif pkg.normalized_name != project_name:
                    packages.append(pkg.spec)
        # install dependent packages in conda
        if self.backend == "conda":
            self.install(packages)
        # install editable packages, including project_name if editable
        for package in editables:
            self.install_editable(package, deps=False)
        # or from wheelhouse if non-editable
        if not project_is_editable:
            index = self.system_path / "wheelhouse"
            if self.backend == "conda":
                index = index / "conda" / project_name / "noarch"
            self.install(
                project_name, deps=False, index=index, prerelease=True
            )
        # install the remaining packages if not in conda
        if self.backend != "conda":
            self.install(packages)

    def lock(self) -> None:
        prefix = self.venv_prefix
        if prefix:
            prefix_lock = prefix.with_name(f"{prefix.name}.lock")
            self._v_lock = FileLock(prefix_lock)
            self._v_lock.acquire()
        else:
            self._v_lock = None

    def unlock(self) -> None:
        # release lock
        if self._v_lock and self._v_lock.is_locked:
            self._v_lock.release()
        self._v_lock = None

    def _venv(self) -> None:
        # activate the venv
        if self.backend == "mingw":
            # do not use venv in mingw
            self._v_lock = self._lock
        else:
            # point to the new environment (or reuse an existing one)
            self.venv_prefix = self.path / (
                f".{self.backend}" if self.backend == "conda" else ".venv"
            )
            self.venv_python = (
                self.venv_prefix / self.relative_bin / self.python.name
            )

            # if python file does not exists, create the new venv
            if not self.venv_python.is_file():
                if self.backend == "conda":
                    self._venv_conda()
                else:
                    self._venv_pip()
            # reuse the venv - point to the existing lock file
            elif self.backend == "pip":
                self._lock = FileLock(self.venv_prefix / ".lock")

    def _venv_conda(self) -> None:
        # create a new conda environment
        prefix = self.venv_prefix
        cmd = f"conda create -p {prefix} -q -y python={PYTHON_VERSION}"
        cmd += " --solver rattler"
        self.run(cmd, cwd=self.system_path)

    def _venv_pip(self) -> None:
        # create venv
        prefix = self.venv_prefix
        if self.backend == "uv":
            python = f"{PYTHON_VERSION}{ABI_THREAD}"
            cmd = f"uv venv --clear --python={python} {prefix}"
        else:
            cmd = f"{self.python} -m venv --clear --upgrade-deps {prefix}"
        self.run(cmd, cwd=self.system_path)

    def cleanup(self) -> None:
        super().cleanup()
        self.unlock()

        # remove venv prefix (to reduce disk usage)
        if not self.request.config.option.venv_keep_prefix:
            prefix = self.venv_prefix
            if self.backend == "conda":

                def _conda_cleanup() -> None:
                    cmd = f"conda remove --all -p {prefix} -q -y --offline"
                    with (
                        io.StringIO() as f,
                        redirect_stdout(f),
                        redirect_stderr(f),
                    ):
                        self.run(cmd, cwd=self.system_path)

                self.request.config.add_cleanup(_conda_cleanup)
            elif self.backend == "mingw":
                # venv is not used in mingw
                pass
            elif isinstance(prefix, Path) and prefix.is_dir():
                rmtree(prefix, ignore_errors=True)


def normalize(name: str) -> str:
    """Normalize a package name."""
    return re.sub(r"[-_.]+", "-", name).lower()


@pytest.fixture
def _tmp_package(
    request: pytest.FixtureRequest,
    tmp_path_factory: pytest.TempPathFactory,
    monkeypatch: pytest.MonkeyPatch,
) -> GeneratorType[TempPackage]:
    """Create package in temporary path, based on source (or sample)."""
    tmp_pkg = TempPackage(request, tmp_path_factory, monkeypatch)
    yield tmp_pkg
    tmp_pkg.cleanup()


@pytest.fixture
def _tmp_package_venv(
    request: pytest.FixtureRequest,
    tmp_path_factory: pytest.TempPathFactory,
    monkeypatch: pytest.MonkeyPatch,
) -> GeneratorType[TempPackage]:
    """Create package in temporary path, based on source (or sample).

    Using a virtual environment.
    """
    tmp_pkg = TempPackageVenv(request, tmp_path_factory, monkeypatch)
    yield tmp_pkg
    tmp_pkg.cleanup()


@pytest.fixture
def tmp_package(request: pytest.FixtureRequest) -> GeneratorType[TempPackage]:
    """Create package in temporary path, based on source (or sample)."""
    # activate venv if has a venv mark using fixture dispatch
    venv_marker = request.node.get_closest_marker(name="venv")
    if venv_marker:
        if not isinstance(venv_marker.kwargs, dict):
            msg = "venv marker kwargs must be a dictionary"
            raise ValueError(msg)
        install_deps = venv_marker.kwargs.get("install_dependencies", True)
        if not isinstance(install_deps, bool):
            msg = "venv marker install_dependencies must be a boolean"
            raise ValueError(msg)

        yield request.getfixturevalue("_tmp_package_venv")
    else:
        yield request.getfixturevalue("_tmp_package")


def pytest_configure(config: pytest.Config) -> None:
    """Register an additional marker."""
    config.addinivalue_line(
        "markers",
        """venv(install_dependencies=True):
        Mark test to run in a virtual environment.

        Args:
            install_dependencies: True [default] or False
        """,
    )


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add options to control venv backend."""
    group = parser.getgroup("venv", "venv backend")
    group.addoption(
        "--venv-backend",
        action="store",
        metavar="BACKEND",
        type=_validate_backend,
        help="Venv backend to use. Default to current venv.",
    )
    group.addoption(
        "--venv-keep-build",
        action="store_true",
        help="Keep build directory of the test.",
    )
    group.addoption(
        "--venv-keep-prefix",
        action="store_true",
        help="Keep venv directory (aka prefix).",
    )
    group.addoption(
        "--venv-prerelease",
        action="store_true",
        default=bool(sys.version_info.releaselevel != "final"),
        help="Enable tests with prerelease versions.",
    )


def _validate_backend(arg: str) -> str:
    valid = {"conda", "mingw", "pip", "uv", "venv"}
    if arg not in valid:
        msg = f"The supported value are: {', '.join(valid)}."
        raise argparse.ArgumentTypeError(msg)
    # TODO: check if arg is really valid, if the backend is installed
    return arg


@pytest.hookimpl(tryfirst=True)
def pytest_cmdline_main(config: pytest.Config) -> None:
    """Set default values to options to control venv backend."""
    if config.option.venv_backend is None:
        if IS_CONDA:
            config.option.venv_backend = "conda"
        elif IS_MINGW:
            config.option.venv_backend = "mingw"
        else:
            virtual_env = os.environ.get("VIRTUAL_ENV")
            if virtual_env is not None:
                pyvenv = Path(virtual_env, "pyvenv.cfg")
                if pyvenv.is_file():
                    if b"uv =" in pyvenv.read_bytes():
                        config.option.venv_backend = "uv"
                    else:
                        config.option.venv_backend = "pip"
            # if not set yet
            if config.option.venv_backend is None:
                if HAVE_UV:
                    config.option.venv_backend = "uv"
                else:
                    config.option.venv_backend = "pip"
    elif config.option.venv_backend == "venv":
        config.option.venv_backend = "pip"
