#!/bin/bash

pyside6-rcc -o _resource.py resource.qrc
