print("Hello from cx_Freeze Advanced #1")

module = __import__("testfreeze_1")
