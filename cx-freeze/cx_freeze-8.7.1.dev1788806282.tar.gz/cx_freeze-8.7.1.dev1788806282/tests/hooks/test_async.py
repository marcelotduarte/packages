"""Tests for hooks of anyio async package.

Implicitly test the asyncio and uvloop packages.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

import pytest

from cx_Freeze._compat import ABI_THREAD

if TYPE_CHECKING:
    from tests.conftest import TempPackage

TIMEOUT = 15

zip_packages = pytest.mark.parametrize(
    "zip_packages", [False, True], ids=["", "zip_packages"]
)

SOURCE_ANYIO = """
test_anyio.py
    import sys

    from anyio import run
    try:
        import uvloop
    except ImportError:
        uvloop = None

    async def main():
        print("Hello from cx_Freeze")

    run(
        main,
        backend_options={
            "use_uvloop": uvloop is not None,
        },
    )
pyproject.toml
    [project]
    name = "test_anyio"
    version = "0.1.2.3"
    dependencies = [
        "anyio<4.15.1",
    ]

    [tool.cxfreeze]
    executables = ["test_anyio.py"]

    [tool.cxfreeze.build_exe]
    include-msvcr = true
    excludes = ["tkinter"]
    silent = true
"""


@pytest.mark.venv
@zip_packages
def test_anyio(
    tmp_package: TempPackage, zip_packages: pytest.MarkDecorator
) -> None:
    """Test if anyio is working correctly."""
    tmp_package.create(SOURCE_ANYIO)
    if zip_packages:
        pyproject = tmp_package.path / "pyproject.toml"
        buf = pyproject.read_bytes().decode().splitlines()
        buf += ['zip_include_packages = "*"', 'zip_exclude_packages = ""']
        pyproject.write_bytes("\n".join(buf).encode("utf_8"))
    if sys.platform != "win32":
        if not (
            sys.version_info == (3, 13) and ABI_THREAD == "t"
        ) and sys.version_info < (3, 15):
            tmp_package.install("uvloop")
    tmp_package.freeze()
    executable = tmp_package.executable("test_anyio")
    assert executable.is_file()
    result = tmp_package.run(executable, timeout=TIMEOUT)
    result.stdout.fnmatch_lines(["Hello from cx_Freeze"])
