

set -ex



cxfreeze --version
exit 0
