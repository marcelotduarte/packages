#!/bin/bash

if [ -z "$CONDA_DEFAULT_ENV" ] &&
   [ -z "$GITHUB_WORKSPACE" ] &&
   [ -z "$VIRTUAL_ENV" ] && [ -z "$2" ]
then
	echo "Required: use of a virtual environment."
    echo "::set-output name=status::1"
	exit 1
fi

if [ -z "$1" ] ; then
	echo "Usage: $0 sample [--pipenv | --venv] [--no-deps]"
	echo "Where:"
	echo "  sample is the name in samples directory (e.g. cryptography)"
	echo "  --pipenv is an option to enable pipenv usage"
	echo "  --venv is an option to enable python venv module usage"
	echo "  --no-deps - disable installing package dependencies"
    echo "::set-output name=status::1"
	exit 1
fi

# Verifiy if python is installed
if ! [ -z `which python` ] ; then
    PYTHON=python
elif ! [ -z `which python3` ] ; then
    PYTHON=python3
else
    echo "ERROR: python not found"
    echo "::set-output name=status::1"
    exit
fi

echo "::group::Prepare the environment"
# Presume unexpected error
echo "::set-output name=status::255"
TEST_SAMPLE=$1
MANAGER=""
INSTALL_DEPS=yes
if ! [ -z "$2" ] ; then
    if [ "$2" == "--pipenv" ] || [ "$2" == "--venv" ] ; then
        MANAGER="$2"
    elif [ "$2" == "--no-deps" ] ; then
        INSTALL_DEPS=no
    fi
fi
# Get script directory (without using /usr/bin/realpath)
CI_DIR=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)
# This script is on ci subdirectory
TOP_DIR=$(cd "$CI_DIR/.." && pwd)
# Get build utilities
source $CI_DIR/build-utils.sh
# python information (platform and version)
PY_PLATFORM=$($PYTHON -c "import sysconfig; print(sysconfig.get_platform())")
PY_VERSION=$($PYTHON -c "import sysconfig; print(sysconfig.get_python_version())")
# Validate bdist_mac action
if ! [[ $PY_PLATFORM == macos* ]] || [ -z "$TEST_BDIST_MAC" ] ; then
    TEST_BDIST_MAC=0
fi
echo "Environment:"
echo "    Platform $PY_PLATFORM"
echo "    Python version $PY_VERSION"
if ! [ -z "$CONDA_EXE" ] ; then
    echo "    $($CONDA_EXE --version)"
fi
echo "::endgroup::"

echo "::group::Check if $TEST_SAMPLE sample exists"
# Check if the samples is in current directory or in a cx_Freeze tree
if [ -d "$TEST_SAMPLE" ] ; then
    TEST_DIR=$(cd "$TEST_SAMPLE" && pwd)
else
    TEST_DIR="${TOP_DIR}/samples/$TEST_SAMPLE"
fi
if ! [ -d "$TEST_DIR" ] ; then
    echo "ERROR: Sample's directory NOT found"
    echo "::endgroup::"
    echo "::set-output name=status::1"
    exit
fi
echo "INFO: The sample is available for test"
pushd "$TEST_DIR" >/dev/null
rm Pipfile 2>/dev/null || true
rm Pipfile.lock 2>/dev/null || true
if [ "$MANAGER" == "--pipenv" ] ; then
    $PYTHON -m pip install --upgrade pipenv
    if [ "$OSTYPE" == "msys" ] ; then
        $PYTHON -m pipenv --python $(cygpath -w `which python`)
    else
        $PYTHON -m pipenv --python $(which python)
    fi
elif [ "$MANAGER" == "--venv" ] ; then
    VENV_NAME=cx_Freeze_${TEST_SAMPLE}_py${PY_VERSION}_${PY_PLATFORM}
    if [ -z "$HOME" ] ; then HOME=$PWD ; fi
    VENV_LOCAL=${HOME}/.local/venv/$VENV_NAME
    $PYTHON -m venv $VENV_LOCAL
    if [[ $PY_PLATFORM == win* ]] ; then
        PYTHON=$VENV_LOCAL/Scripts/python.exe
    else
        source $VENV_LOCAL/bin/activate
        PYTHON=python
    fi
fi
echo "::endgroup::"

echo "::group::Install platform specific utilities/packages"
# started before the build because tk (and qt) depend on $DISPLAY
install_xvfb $PY_PLATFORM
start_xvfb $PY_PLATFORM
install_screen_capture $PY_PLATFORM
install_x11_tools $PY_PLATFORM
echo "::endgroup::"

echo "::group::Install dependencies for $TEST_SAMPLE sample"
if [ "$INSTALL_DEPS" == "yes" ] ; then
    WHEELHOUSE="${TOP_DIR}/wheelhouse"
    if [ -d "$WHEELHOUSE" ] ; then
        export PIP_FIND_LINKS="$WHEELHOUSE"
    fi
    export PIP_DISABLE_PIP_VERSION_CHECK=1
    $PYTHON "${CI_DIR}/build_test.py" "$TEST_DIR" --install-requires
    if [ $? != 0 ]; then
        # somentimes in conda, occurs error 247 if occurs downgrade of python
        #$PYTHON "${CI_DIR}/build_test.py" "$TEST_DIR" --install-requires
        echo "ooooooooooooooooooooooooooo"
    fi
else
    echo "INFO: Skipping"
fi
TEST_CXFREEZE="import cx_Freeze; print(cx_Freeze.__version__)"
if [ -e Pipfile ] ; then
    CXFREEZE_VERSION=$($PYTHON -m pipenv run python -c "${TEST_CXFREEZE}")
else
    CXFREEZE_VERSION=$($PYTHON -c "${TEST_CXFREEZE}")
fi
TEST_EXITCODE=$?
echo "::endgroup::"
if ! [ "$TEST_EXITCODE" == "0" ] ; then
    echo "::set-output name=status::$TEST_EXITCODE"
    exit
fi

echo "::group::Show packages"
if [ -e Pipfile ] ; then
    $PYTHON -m pipenv graph
elif ! [ -z "$CONDA_DEFAULT_ENV" ] ; then
    $CONDA_EXE list -n $CONDA_DEFAULT_ENV
else
    $PYTHON -VV
    $PYTHON -m pip list -v
fi
echo "::endgroup::"

echo "::group::Freeze $TEST_SAMPLE sample (cx_Freeze $CXFREEZE_VERSION)"
TEST_OPTIONS="--silent"
if ! [ "$TEST_SAMPLE" == "tkinter" ] ; then
    TEST_OPTIONS="$TEST_OPTIONS --excludes=tkinter"
fi
if [[ $PY_PLATFORM == win* ]] ; then
    TEST_OPTIONS="$TEST_OPTIONS --include-msvcr=true"
fi
if [ -e Pipfile ] ; then
    $PYTHON -m pipenv run python setup.py build_exe $TEST_OPTIONS
else
    if [ "$TEST_BDIST_MAC" != "0" ]; then
        $PYTHON setup.py build_exe $TEST_OPTIONS bdist_mac
    else
        $PYTHON setup.py build_exe $TEST_OPTIONS
    fi
fi
TEST_EXITCODE=$?
echo "::endgroup::"
if ! [ "$TEST_EXITCODE" == "0" ] ; then
    echo "::set-output name=status::$TEST_EXITCODE"
    exit
fi

echo "::group::Prepare to run the first $TEST_SAMPLE sample"
popd >/dev/null
BUILD_DIR="${TEST_DIR}/build/exe.${PY_PLATFORM}-${PY_VERSION}"
pushd "${BUILD_DIR}" >/dev/null
count=0
TEST_NAME=$($PYTHON "${CI_DIR}/build_test.py" "$TEST_SAMPLE" --get-app=$count)
# store the last service app
TEST_SVC_PID=
TEST_SVC_LOG=
until [ -z "$TEST_NAME" ] ; do
    # check the app type and remove that info from the app name
    if [[ $TEST_NAME == gui:* ]] ; then
        TEST_APPTYPE=gui
        TEST_NAME=${TEST_NAME:4}
    elif [[ $TEST_NAME == svc:* ]] ; then
        TEST_APPTYPE=svc
        TEST_NAME=${TEST_NAME:4}
        if [ "$TEST_NAME" == "kill" ] ; then
            TEST_APPTYPE=kill
        fi
    elif [[ $TEST_NAME == cmd:* ]] ; then
        TEST_APPTYPE=cmd
        TEST_NAME=${TEST_NAME:4}
    else
        TEST_APPTYPE=cui
    fi
    TEST_NAME_ARGV=(${TEST_NAME})
    TEST_NAME_BASE=$(basename ${TEST_NAME_ARGV[0]})
    echo "Base: $TEST_NAME_BASE"
    # get the full name for some cases
    if [ "$TEST_APPTYPE" == "cmd" ] || [ "$TEST_APPTYPE" == "kill" ] ; then
        TEST_NAME_FULL="$TEST_NAME"
    else
        TEST_NAME_FULL="./$TEST_NAME"
        if [ "$TEST_BDIST_MAC" != "0" ] ; then
            # adjust the app name if run on bdist_mac
            names=(../*.app)
            TEST_DIR_BDIST=$(cd "${names[0]}/Contents/MacOS" && pwd)
            TEST_NAME_FULL="$TEST_DIR_BDIST/$TEST_NAME"
            #if [ "$TEST_BDIST_MAC" == "2" ] ; then
            #    mv $TEST_DIR_BDIST/*.dylib $TEST_DIR_BDIST/lib/ || true
            #fi
        fi
    fi
    if [ "$TEST_APPTYPE" == "kill" ] ; then
        TEST_LOG="$TEST_SVC_LOG"
    else
        echo "Full: $TEST_NAME_FULL"
        # log name
        TEST_OUTPUT="$TEST_SAMPLE-$count-$TEST_NAME_BASE-$PY_PLATFORM-$PY_VERSION"
        TEST_LOG="${TEST_OUTPUT}.log"
    fi
    echo "Output: $TEST_LOG"
    echo "::endgroup::"
    echo "::group::Run $TEST_NAME"
    # prepare the environment and run the app
    if [ "$TEST_APPTYPE" == "gui" ] ; then
        # GUI app is started in backgound to not block the execution
        if [ ${#TEST_NAME_ARGV[@]} == 1 ] ; then
            "$TEST_NAME_FULL" &> "$TEST_LOG" &
        else
            $TEST_NAME_FULL &> "$TEST_LOG" &
        fi
        TEST_PID=$!
        echo "Process $TEST_PID started in background"
        # make a screenshot after a timeout
        if [[ $PY_PLATFORM == macos* ]] ; then
            if [ -e /usr/sbin/screencapture ] ; then
                /usr/sbin/screencapture -T 30 "${TEST_OUTPUT}.png"
                echo "Taking a capture of the whole screen to ${TEST_OUTPUT}.png"
            else
                echo "WARNING: screencapture not found"
            fi
        elif [[ $PY_PLATFORM == linux* ]] ; then
            if [ "$CI" == "true" ] || ! which gnome-screenshot &>/dev/null
            then
                if which import &>/dev/null ; then
                    echo "INFO: using ImageMagick to capture the screen"
                    sleep 10
                    import -window root "${TEST_OUTPUT}.png"
                    echo "Taking a capture of the whole screen to"
                    echo "file://${PWD}/${TEST_OUTPUT}.png"
                else
                    echo "WARNING: fallback ImageMagick not found"
                fi
            else
                gnome-screenshot --delay=10 --file="${TEST_OUTPUT}.png"
                echo "Taking a capture of the whole screen to"
                echo "file://${PWD}/${TEST_OUTPUT}.png"
            fi
        elif [[ $PY_PLATFORM == mingw* ]] || [[ $PY_PLATFORM == win* ]] ; then
            if [ -e $HOME/bin/screencapture.exe ] ; then
                sleep 15
                $HOME/bin/screencapture.exe "${TEST_OUTPUT}.png"
            else
                echo "WARNING: screencapture not found"
            fi
        fi
    elif [ "$TEST_APPTYPE" == "svc" ] ; then
        # service app is started in backgound too
        if [ ${#TEST_NAME_ARGV[@]} == 1 ] ; then
            "$TEST_NAME_FULL" &> "$TEST_LOG" &
        else
            $TEST_NAME_FULL &> "$TEST_LOG" &
        fi
        TEST_SVC_PID=$!
        TEST_SVC_LOG="$TEST_LOG"
        TEST_PID=
        TEST_LOG=
        echo "Process $TEST_SVC_PID started in background"
    elif [ "$TEST_APPTYPE" == "kill" ] ; then
        # kill the service app in background
        TEST_PID=$TEST_SVC_PID
        TEST_LOG="$TEST_SVC_LOG"
        TEST_SVC_PID=
        TEST_SVC_LOG=
    else
        # for TEST_APPTYPE==cmd - run on current console
        # for TEST_APPTYPE==cui - run console app and capture its results
        if [ ${#TEST_NAME_ARGV[@]} == 1 ] ; then
            ("$TEST_NAME_FULL" &> "$TEST_LOG")
        else
            ($TEST_NAME_FULL &> "$TEST_LOG")
        fi
        TEST_EXITCODE=$?
        TEST_PID=
    fi
    # check for exit code
    if ! [ -z "$TEST_PID" ] ; then
        if kill -0 $TEST_PID &>/dev/null ; then
            kill -9 $TEST_PID
            echo "Process $TEST_PID killed after a timeout"
        fi
        wait $TEST_PID &>/dev/null || TEST_EXITCODE=$?
        echo "Process $TEST_PID returned with exitcode $TEST_EXITCODE"
    fi
    if ! [ -z "$TEST_LOG" ] && [ -f "$TEST_LOG" ] ; then
        TEST_LOG_HAS_ERROR=N
        if [ $(wc -c "$TEST_LOG" | awk '{print $1}') != 0 ] ; then
            # generic errors and
            # error for pyqt5
            # error for pyside2
            # error for pythonnet
            if grep -q -i "error:" $TEST_LOG ||
               grep -q -i "Reinstalling the application may f" $TEST_LOG ||
               grep -q -i "Unable to import shiboken" $TEST_LOG ||
               grep -q -i "Unhandled Exception:" $TEST_LOG
            then
                # ignore error for wxPython 4.1.1
                # https://github.com/wxWidgets/Phoenix/commit/040c59fd991cd08174b5acee7de9418c23c9de33
                if [[ $PY_PLATFORM == mingw* ]] &&
                   [ "$TEST_SAMPLE" == "matplotlib" ] &&
                   grep -q 'Error: Unable to set default locale:' $TEST_LOG
                then
                    TEST_LOG_HAS_ERROR=N
                else
                    TEST_LOG_HAS_ERROR=Y
                fi
            fi
        fi
        if [ $TEST_LOG_HAS_ERROR == Y ]; then
            if [ -z "$TEST_EXITCODE" ] || [ "$TEST_EXITCODE" == "0" ] ; then
                TEST_EXITCODE=255
            fi
            echo "Process $TEST_PID error $TEST_EXITCODE"
        elif [ "$TEST_APPTYPE" == "gui" ] ; then
            if ! [ -z "$TEST_EXITCODE" ] && [ "$TEST_EXITCODE" != "0" ] ; then
                echo "Process $TEST_PID error $TEST_EXITCODE IGNORED"
            fi
            TEST_EXITCODE=0
        fi
    fi
    echo "::endgroup::"
    if ! [ -z "$TEST_LOG" ] && [ -f "$TEST_LOG" ] ; then
        echo "::group::Print output"
        if [[ $PY_PLATFORM == mingw* ]] && [ "$CI" == "true" ] ; then
            (mintty --title "$TEST_NAME" --hold always --exec cat "$TEST_LOG")&
        else
            echo `printf '=%.0s' {1..40}`
            cat "$TEST_LOG"
            echo `printf '=%.0s' {1..40}`
        fi
        if ! [ "$TEST_EXITCODE" == "0" ] ; then
            echo "::endgroup::"
            echo "::set-output name=status::$TEST_EXITCODE"
            exit
        fi
        if [[ $PY_PLATFORM == linux* ]] && [ "$TEST_APPTYPE" == "cui" ] ; then
            echo "::endgroup::"
            echo "::group::Run $TEST_NAME sample in docker"
            docker run --rm -t -v `pwd`:/frozen ubuntu:18.04 /frozen/$TEST_NAME
        fi
        echo "::endgroup::"
    fi
    echo "::group::Prepare to run the next $TEST_SAMPLE sample"
    count=$(( $count + 1 ))
    TEST_NAME=$($PYTHON "${CI_DIR}/build_test.py" $TEST_SAMPLE --get-app=$count)
done
popd >/dev/null
kill_xvfb $PY_PLATFORM
echo "::endgroup::"
echo "::set-output name=status::$TEST_EXITCODE"
